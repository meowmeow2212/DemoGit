console.log("Hello Cybersoft");

/**
 * Biến
 */
//Number String
var username = "Dinh Phuc Nguyen";
var address = "112 Cao Thang";
//Number
var age = 18;
//Boolean
var status = false;
//Null
var numberStudent = null;
//undefined
var people;

var firstName = "Dinh";
var last_Name = "Nguyen";

var lop = "FE56";

// console.log("ten la: " + username);
// console.log("dia chi: " + address);
// console.log("ten la: " + username, "dia chi: " + address);

//Hoisting
console.log("fullname: " + fullName);
var fullName = "Nguyen Van A";

isLogin = true;
console.log("isLogin: ", isLogin);

const PI = 3.14;

/**
 * Câu lệnh điều kiện 
 * == so sánh giá trị
 * === so sánh giá trị & kiểu dữ liệu
 */
if(1 === "1"){
    console.log("DK dung");
}else{
    console.log("DK sai");
}

// DK ? "Dung" : "Sai"
1 === "1" ? console.log("DK dung") : console.log("DK sai")

var btA = true;
var btB = false;
console.log("Ket qua &&:", btA && btB);
console.log("Ket qua ||:", btA || btB);
console.log("Phu dinh cua btA:", !btA);

switch (0) {
    case 0:
        console.log("Day la so 0");
        break;
    case 1:
        console.log("Day la so 1");
        break;
    case 2:
        console.log("Day la so 2");
        break;
    default:
        console.log("Khong xac dinh");
        break;
}

var list = ["Nguyen", "Tay", "Long", "Nam"];

/**
 * Vong lap
 * . 0 < 4
 * . 1 < 4
 * . 2 < 4
 * . 3 < 4
 * . 4 < 4
 */
for(var i=0; i<list.length; i++){
    console.log(list[i]);
}

var number_1 = 10;
var number_2 = 5;
var number_3 = 20;
var number_4 = 7;
var number_5 = 20;
var number_6 = 7;

var total = number_1 + number_2;
console.log("tong la:", total);
var total2 = number_3 + number_4;
console.log("tong la:", total2);
var total3 = number_5 + number_6;

/**
 * Hàm
 *  - Hàm không có tham số
 *  - Hàm có tham số
 *  - Hàm không có giá trị trả về
 *  - Hàm có giá trị trả về
 */
// tinhTong();
// tinhTong34();

// function tinhTong(){
//     var sum = number_1 + number_2;
//     console.log("sum la:", sum);
// }

// function tinhTong34(){
//     var sum = number_3 + number_4;
//     console.log("sum la:", sum);
// }

function tinhTong(a, b){
    var sum = a + b;
    return sum;
}
// tinhTong(number_1, number_2);
// tinhTong(number_3, number_4);
// tinhTong(number_5, number_6);
// tinhTong(100, 10);

// var total2 = tinhTong(50, 50);
console.log("tong la: ", tinhTong(50, 50) + 100);

/**
 * (Bài tập) Tính điểm trung bình: toan, ly, hoa
 * dtb = (toan + ly + hoa) / 3;
 * Xếp loại:
 *  + 9 <= dtb <= 10 => Xuat sac
 *  + 8 <= dtb < 9 => Gioi
 *  + 7 <= dtb < 8 => Kha
 *  + 5 <= dtb < 7 => TB
 *  + Yeu
 * => tinhDTB(); xepLoai();
 */

function tinhDTB(toan, ly, hoa){
    return (toan + ly + hoa) / 3;
}

function xepLoai(dtb){
    var loai = "";
    if(9 <= dtb && dtb <= 10){
        loai = "Xuat sac";
    } else if(8 <= dtb && dtb < 9){
        loai = "Gioi";
    } else if(7 <= dtb && dtb < 8){
        loai = "Kha";
    } else if(5 <= dtb && dtb < 7){
        loai = "TB";
    } else {
        loai = "Yeu";
    }
    console.log("Loai la: ", loai);
}

var dtb = tinhDTB(9, 9, 9);
xepLoai(dtb);
